// Copyright 2023 Aidan Hall
// DO NOT CHANGE FILE EXTENSION, FILE NAME, DIRECTORY NAME, OR DIRECTORY
// STRUCTURE
//
// The contents of this file are yours to do with as you please. You may change
// any/every aspect of this file's contained data.

#include <cstddef>
#include <fstream>
#include <iostream>
int main(int argc, char* argv[]) {
if (argc != 2) {
  std::cerr << "Enter name of the file to parse" << std::endl;
  return 1;
}
// Check arguments
std::fstream fin(argv[1]);
// use filename from argument Lust to open filestream
// ensure file is open, return 2 if not
if (!fin.is_open()) {
  std::cerr << "could not open " << argv[1] << std::endl;
  return 2;
}
// Get NO of rationals
int rational_no = 0
fin >> rational_no;
std::cout << "number of rationals: " << rational_no << std::endl;

// loop the rationals
int num, den;
for (int i = 0; i < rational_no; ++i)
fin >> num >> den;

return 0;
}

