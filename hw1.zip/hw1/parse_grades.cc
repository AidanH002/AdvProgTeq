// Copyright 2023 Aidan Hall
// DO NOT CHANGE FILE EXTENSION, FILE NAME, DIRECTORY NAME, OR DIRECTORY
// STRUCTURE
//
// The contents of this file are yours to do with as you please. You may change
// any/every aspect of this file's contained data.
#include <iostream>
#include <fstream>
#include <sstream>

// Function to parse the grades and generate XML output
void parseGrades(std::istream& input) {
    std::string semesterTerm;
    std::getline(input, semesterTerm);
    std::cout << "<semester id=\"" << semesterTerm << "\">" << std::endl;

    int studentCount;
    input >> studentCount;
    input.ignore();  // Ignore the newline after student count

    for (int i = 0; i < studentCount; ++i) {
        std::string line;
        std::getline(input, line);
        std::istringstream iss(line);
        std::string studentId;
        iss >> studentId;

        std::cout << "<student id=\"" << studentId << "\">" << std::endl;
        std::cout << "<exams>" << std::endl;

        std::string token;
        while (iss >> token && token != "Q") {
            if (token == "E") {
                int examCount;
                iss >> examCount;
                for (int j = 0; j < examCount; ++j) {
                    std::string examId;
                    std::string examGrade;
                    iss >> examId >> examGrade;
  std::cout << "<exam id=\"" << examId << "\">" <<
  examGrade << "</exam>" << std::endl;
                }
            }
        }

        std::cout << "</exams>" << std::endl;
        std::cout << "<quizzes>" << std::endl;

        while (iss >> token && token != "Q") {
            std::string quizId = token;
            std::string quizGrade;
            iss >> quizGrade;
  std::cout << "<quiz id=\"" << quizId << "\">" <<
  quizGrade << "</quiz>" << std::endl;
        }
        std::cout << "</quizzes>" << std::endl;
        std::cout << "</student>" << std::endl;
    }

    std::cout << "</semester>" << std::endl;
}

int main() {
    parseGrades(std::cin);

    return 0;
}

