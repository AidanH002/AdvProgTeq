//  This class tests your ability to manage operator overloading.
//
//  Points:
//   Style : 1
//   Compilation : 1
//    -csce240::Tax::operator* : 1
//    -csce240::operator* : 1
//    -csce240::operator>> : 1
//    -csce240::operator<< : 1
//


// Tax class representing a tax code as a string and a percent tax as a double.
// Is in the csce240 namespace
//


  // Default constructor--Tax():
  //   - tax code is empty string,
  //   - tax percent is 0.0
  //


  // Complete constructor--Tax(const std::string&, double):
  //   Parameters:
  //     - a read-only string reference to initialize tax code and
  //     - a double to initialize tax percentage
  //   Precondition: percentage is positive
  //


  // code getter returns tax instance code; is const---does not modify calling
  //   class
  //


  // percent getter returns tax instance percentage as a percent [0.0, 1.0]; is
  //   const---does not modify calling instance
  //


  //  Multiply operator--operator*(double rhs)--overload accepts a double,
  //  applies the stored tax percent, and returns product of taxation; method
  //  does not modify calling instance---is const
  //
  //  Precondition: double parameter is positive
  //


  // Extract method--Extract(std::ostream*)--appends the code and tax in the
  // format:
  //   AAA:00.0
  // To the ostream pointer output parameter.
  // Returns the ostream* parameter as an ostream pointer
  //


  // Insert method--Insert(std::istream*)--removes a string and double from the
  // input stream in the format,
  //   AAA 00.0
  // storing in the calling instance.
  //
  // Precondition: there exists a whitespace-delimited string and numeric on
  //               the stream in the form:
  //   AAA 00.0
  //


//  Multiply operator (operator*) function overload accepts a double and a
//  read-only Tax reference. It applies the right-hand-side's  stored tax
//  percent, and returns product of taxation; method does not modify the Tax
//  reference---it is const
//
//  Precondition: double parameter is positive


// Extract (operator<<) and input (operator>>) operators are both overloaded in
// the standard way.

