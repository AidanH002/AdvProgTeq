// Copyright 2023 CSCE 240
//
#ifndef HW3_INC_TEST_CHAR_MATRIX_H_
#define HW3_INC_TEST_CHAR_MATRIX_H_


#include <hw3/inc/char_matrix.h>  // api being tested
#include <hw3/inc/char_matrix.h>  // DO NOT DELETE
#include <hw3/inc/test_utils.h>  // helper functions

#include <cstddef>  // std::size_t
#include <cstdlib>  // std::atoi
#include <cstring>  // std::strlen, std::strcmp
#include <iostream>
#include <string>
#include <sstream>


// These will change in subsequent tests
const std::size_t kRectangleRows = 2;
const std::size_t kRectangleCols[] = { 3, 3 };

// Create arrays:
//   { { , , },
//     { , , } }
//
const char **kRectangleDefault{ new const char *[kRectangleRows]{
  // requires one array literal per row (kTestRows)
  new const char[kRectangleCols[0]]{ '\0', '\0', '\0' },
  new const char[kRectangleCols[1]]{ '\0', '\0', '\0' }
} };


// Used to test initalization; will change is subseqent tests
const char kInitVal = ';';

//   { { ';', ';', ';' },
//     { ';', ';', ';' } }
//
const char **kRectangleInitialized{ new const char *[kRectangleRows]{
  // requires one array literal per row (kTestRows)
  new const char[kRectangleCols[0]]{
    kInitVal, kInitVal, kInitVal
  },
  new const char[kRectangleCols[1]]{
    kInitVal, kInitVal, kInitVal
  }
} };

//   { { 'a', 'b', 'c' },
//     { 'd', 'e', 'f' } }
//
const char **kRectangleLetters{ new const char *[kRectangleRows]{
  // requires one array literal per row (kTestRows)
  new const char[kRectangleCols[0]]{
    'a', 'b', 'c'
  },
  new const char[kRectangleCols[1]]{
    'd', 'e', 'f'
  }
} };
const std::size_t kRectangleLen = 6;  // used by TestToCStringRectangle
const char *kRectangleCString = "abcdef";


const std::size_t kJaggedRows = 3;
const std::size_t kJaggedCols[] = { 4, 2, 3 };

// { { ';', ';', ';', ';' },
//   { ';', ';', } },
//   { ';', ';', ';' }
const char **kJagged{ new const char *[kJaggedRows]{
  new const char[kJaggedCols[0]]{
    kInitVal, kInitVal, kInitVal, kInitVal
  }, new const char[kJaggedCols[1]]{
    kInitVal, kInitVal
  }, new const char[kJaggedCols[2]]{
    kInitVal, kInitVal, kInitVal
  }
} };


const std::size_t kJaggedLettersRows = 3;
const std::size_t kJaggedLettersCols[] = { 4, 2, 3 };

// { { 'A', 'B', 'C', 'D' },
//   { 'E', 'F' } },
//   { 'G', 'H', 'I' }
const char **kJaggedLetters{ new const char *[kJaggedRows]{
  new const char[kJaggedCols[0]]{
    'A', 'B', 'C', 'D'
  }, new const char[kJaggedCols[1]]{
    'E', 'F' 
  }, new const char[kJaggedCols[2]]{
    'G', 'H', 'I'
  }
} };

const std::size_t kJaggedLen = 9;
const char* kJaggedCString = "ABCDEFGHI";

#endif  // HW3_INC_TEST_CHAR_MATRIX_H_
