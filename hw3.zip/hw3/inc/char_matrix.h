// Copyright 2023 Aidan Hall
#ifndef HW3_INC_CHAR_MATRIX_H_  // HW3_INC_CHAR_MATRIX_H_
#define HW3_INC_CHAR_MATRIX_H_  // HW3_INC_CHAR_MATRIX_H_
#include <cstddef>  // std::size_t


// Creates a two-dimensional array of given size and returns pointer to memory.
// It uses start val to intialize the elements of the array(s).

char** Allocate(std::size_t rows,
                const std::size_t cols[],
                char start_val = '\0');


// Returns all memory used by parameter "delete_me" to memory manager
void Deallocate(std::size_t rows, const std::size_t cols[],
                char** delete_me);


// Creates and returns a new array from existing source array. Function
// allocates as much memory as necessary to exactly copy the rows and columns
// of the source array. It next copies each element from the source array(s)
// into the new array(s) and returns the new array(s).
char** Clone(const char** source, std::size_t rows, const std::size_t cols[]);


// Creates and returns a new c-string---a null-terminated character array.
// Function allocates as much memory as needed to create a one-dimensional
// array; a c-string. The function allocates one extra byte to allow for the
// null character at the end of the new array. Copies the elements of the
char* ToCString(const char** source,
                std::size_t rows, const std::size_t cols[]);
#endif  // HW3_INC_CHAR_MATRIX_H_
