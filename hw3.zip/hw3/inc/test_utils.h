// Copyright 2023 CSCE 240
//
#ifndef HW3_INC_TEST_TEST_UTILS_H_
#define HW3_INC_TEST_TEST_UTILS_H_


#include <cassert>  // assert
#include <cstddef>  // std::size_t
#include <cstdlib>  // std::atoi
#include <iostream>
#include <string>
#include <sstream>


// Performs an element-by-element comparison of expected and actual. Does not
// use approximation. The actual values must be a direct copy of the expected
// values.
//
bool ArraysEqual(const char** lhs, const char** rhs,
                 std::size_t rows, const std::size_t cols[]);


// Returns a string of the form EXPECTED: <expected> ACTUAL: <actual>.
//
const std::string FormatFailString(const char** expected,
                                   const char** actual,
                                   std::size_t rows,
                                   const std::size_t cols[]);


// Uses the stringstream to convert the elements of the array in a string.
// Column entries are delimited by commas and rows by new lines.
std::stringstream* FormatFailString(const char* from,
                                    std::size_t cols,
                                    std::stringstream* to);

#endif  // HW3_INC_TEST_TEST_UTILS_H_
