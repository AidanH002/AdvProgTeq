// Copyright 2023 CSCE 240
//
#include <hw3/inc/test_char_matrix.h>

#include <cstddef>  // std::size_t
#include <cstdlib>  // std::atoi
#include <iostream>


// Tests Allocate function with rectangle matrix and no init value
bool TestAllocateRectangle(std::string* results);

// Tests Allocate function with rectangle matrix and init
bool TestAllocateInitializedRectangle(std::string* results);

// Tests Allocate function with jagged matrix and init
bool TestAllocateJaggedRectangle(std::string* results);

// recursive; used to call one or all of the above-declared functions
bool TestDispatcher(int test);


// main entry point
//
// to test fuctions
int main(int argc, char* argv[]) {
  const std::size_t kTestNoArg = 1;

  if (TestDispatcher(argc == 1 ? -1 : std::atoi(argv[kTestNoArg])))
    return 0;

  return 1;
}


// 
bool TestDispatcher(int test) {
  if (test != 1 && test != 2) {
    // input is not valid test; run all tests
    bool passed = true;
    for (int i = 1; i < 3; ++i)
      passed = TestDispatcher(i) && passed;
    
    return passed;
  } else {
    std::string results;  // messages from test functions
    int failed = 0;

    switch (test) {
      case 1: {
        // test Allocate with rectangular array
        std::cout << "RUNNING TestAllocateRectangle: ";
        if (TestAllocateRectangle(&results)) {
          std::cout << "PASSED" << std::endl;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          ++failed;
        }
        // test Allocate with rectangular array and initialization
        std::cout << "RUNNING TestAllocateInitializedRectangle: ";
        if (TestAllocateInitializedRectangle(&results)) {
          std::cout << "PASSED" << std::endl;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          ++failed;
        }
        if (failed) {
          std::cout << "TESTS FAILED: "  << (failed == 1 ? 1 : 2)
            << "\n  Zero points awarded" << std::endl;
          return false;
        }
        return true;
      }
      case 2:  // test Allocate with jagged array and initialization
        std::cout << "RUNNING TestAllocateJaggedRectangle: ";
        if (TestAllocateJaggedRectangle(&results)) {
          std::cout << "PASSED" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
      }
    }
    return false;
}


bool TestAllocateRectangle(std::string* results) {
  // TEST Allocate function
  char **actual = Allocate(kRectangleRows, kRectangleCols);

  // Compare to expected
  bool passed = ArraysEqual(kRectangleDefault,
                            const_cast<const char**>(actual),
                            kRectangleRows, kRectangleCols);

  // when test failed, print cause
  if (!passed)
    *results = FormatFailString(kRectangleDefault,
                                const_cast<const char**>(actual),
                                kRectangleRows,
                                kRectangleCols)
             + '\n';

  // Must pass both tests to pass function
  return passed;
}


bool TestAllocateInitializedRectangle(std::string* results) {
  // TEST Allocate function
  char **actual = Allocate(kRectangleRows, kRectangleCols, kInitVal);

  // Compare to expected
  bool passed = ArraysEqual(kRectangleInitialized,
                            const_cast<const char**>(actual),
                            kRectangleRows, kRectangleCols);

  // when test failed, print cause
  if (!passed)
    *results = FormatFailString(kRectangleInitialized,
                                const_cast<const char**>(actual),
                                kRectangleRows,
                                kRectangleCols)
             + '\n';

  // Must pass both tests to pass function
  return passed;
}


bool TestAllocateJaggedRectangle(std::string* results) {
  // TEST Allocate function
  char **actual = Allocate(kJaggedRows, kJaggedCols, kInitVal);

  // Compare to expected
  bool passed = ArraysEqual(kJagged,
                            const_cast<const char**>(actual),
                            kJaggedRows, kJaggedCols);

  // when test failed, print cause
  if (!passed)
    *results = FormatFailString(kJagged,
                                const_cast<const char**>(actual),
                                kJaggedRows,
                                kJaggedCols)
             + '\n';

  // Must pass both tests to pass function
  return passed;
}
