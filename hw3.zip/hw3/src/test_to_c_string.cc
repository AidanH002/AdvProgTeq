// Copyright 2023 CSCE 240
//
#include <hw3/inc/test_char_matrix.h>


// tests ToCString function's correctness deleteing a rectangular array
bool TestToCStringRectangle(std::string* results);

// tests ToCString function's correctness deleting a jagged array
bool TestToCStringJagged(std::string* results);

// recursive; used to call one or both of the two above-declared functions
bool TestDispatcher(int test = 0);


// main function
//
// Entry point to tests
int main(int argc, char* argv[]) {
  const std::size_t kTestNoArg = 1;

  // if no test no NOT provided, any integer NOT in [1, 2] will work; using -1
  if (TestDispatcher(argc == 1 ? -1 : std::atoi(argv[kTestNoArg])))
    // test(s) successful
    return 0;

  return 1;
}


// 
bool TestDispatcher(int test) {
  if (test != 1 && test != 2) {
    // input is not valid test; run all tests
    bool passed = true;
    for (int i = 1; i < 3; ++i)
      passed = TestDispatcher(i) && passed;
    
    return passed;
  } else {
    std::string results;  // messages from test functions

    switch (test) {
      case 1:
        // test ToCString with rectangular array
        std::cout << "RUNNING TestToCStringRectangle: ";
        // call test and capture any messages in results
        if (TestToCStringRectangle(&results)) {
          std::cout << "PASSED" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
      case 2:  // test ToCString with jagged array
        std::cout << "RUNNING TestToCStringJagged: ";
        // call test and capture any messages in results
        if (TestToCStringJagged(&results)) {
          std::cout << "PASSED" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
    }
  }
  return false;
}


// helper function exclusive to these two tests, in scope for them, alone
const std::string FormatFailString(std::size_t expected, std::size_t actual) {
  std::stringstream formatter;
  formatter << "  Expected: " << expected << ", Actual: " << actual;
  return formatter.str();
}
const std::string FormatFailString(const char* expected, const char* actual) {
  std::stringstream formatter;
  formatter << "  Expected: " << expected << ", Actual: " << actual;
  return formatter.str();
}

bool TestToCStringRectangle(std::string* results) {
  // request memory and convert to c-string
  char *actual = ToCString(kRectangleLetters,
                           kRectangleRows,
                           kRectangleCols);

  // compare to expected length
  std::size_t actual_len = std::strlen(actual);
  bool passed = actual_len == kRectangleLen;
  if (!passed)
    *results = FormatFailString(kRectangleLen, actual_len) + '\n';

  // compare to expected value
  if (strcmp(actual, kRectangleCString) != 0) {
  // when test failed, print cause
    *results = FormatFailString(kRectangleCString, actual) + '\n';
    passed = false;
  }

  // return memory used
  if (actual)
    delete [] actual;

  // must pass both tests to pass function
  return passed;
}


bool TestToCStringJagged(std::string* results) {
  // request memory and convert to c-string
  char *actual = ToCString(kJaggedLetters,
                           kJaggedRows,
                           kJaggedCols);

  // compare to expected length
  std::size_t actual_len = std::strlen(actual);
  bool passed = actual_len == kJaggedLen;
  if (!passed)
    *results = FormatFailString(kJaggedLen, actual_len) + '\n';

  // compare to expected value
  if (strcmp(actual, kJaggedCString) != 0) {
  // when test failed, print cause
    *results = FormatFailString(kJaggedCString, actual) + '\n';
    passed = false;
  }

  // return memory used
  if (actual)
    delete [] actual;

  // must pass both tests to pass function
  return passed;
}
