// Copyright 2023 Aidan Hall
#include <hw3/inc/char_matrix.h>

#include <cstddef>  // std::size_t
#include <cstring>  // std::strlen
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
char** Allocate(std::size_t rows, const std::size_t* cols, char start_val) {
  char** matrix = new char*[rows];
  for (std::size_t i = 0; i < rows; ++i) {
    matrix[i] = new char[cols[i] + 1];  // Add 1 for null-terminator
    std::memset(matrix[i], start_val, cols[i]);
    matrix[i][cols[i]] = '\0';  // Null-terminate the row
  }
  return matrix;
}

void Deallocate(std::size_t rows, const std::size_t* cols, char** matrix) {
  for (std::size_t i = 0; i < rows; ++i) {
    delete[] matrix[i];
  }
  delete[] matrix;
}

char** Clone(const char** matrix, std::size_t rows, const std::size_t* cols) {
  char** cloned_matrix = Allocate(rows, cols);
  for (std::size_t i = 0; i < rows; ++i) {
    std::memcpy(cloned_matrix[i], matrix[i], cols[i]);
    cloned_matrix[i][cols[i]] = '\0';  // Null-terminate the row
  }
  return cloned_matrix;
}
char* ToCString(const char** matrix,
                std::size_t rows,
                const std::size_t* cols) {
  std::size_t total_size = 0;
  for (std::size_t i = 0; i < rows; ++i) {
    total_size += cols[i];
  }

  char* result = new char[total_size + 1];
  char* current = result;

  for (std::size_t i = 0; i < rows; ++i) {
    for (std::size_t j = 0; j < cols[i]; ++j) {
      *current++ = matrix[i][j];
    }
  }

  *current = '\0';  // Add null-terminator at the end

  return result;
}
