// Copyright 2023 CSCE 240
//
#include <hw3/inc/test_char_matrix.h>


// tests Clone function's correctness deleting a rectangular array
bool TestCloneRectangle(std::string* results);

// tests Clone function's correctness deleting a jagged array
bool TestCloneJagged(std::string* results);

// recursive; used to call one or both of the two above-declared functions
bool TestDispatcher(int test = 0);


// main function
//
// Entry point to tests
int main(int argc, char* argv[]) {
  const std::size_t kTestNoArg = 1;

  // if no test no NOT provided, any integer NOT in [1, 2] will work; using -1
  if (TestDispatcher(argc == 1 ? -1 : std::atoi(argv[kTestNoArg])))
    // test(s) successful
    return 0;

  return 1;
}


// 
bool TestDispatcher(int test) {
  if (test != 1 && test != 2) {
    // input is not valid test; run all tests
    bool passed = true;
    for (int i = 1; i < 3; ++i)
      passed = TestDispatcher(i) && passed;
    
    return passed;
  } else {
    std::string results;  // messages from test functions

    switch (test) {
      case 1:
        // test Clone with rectangular array
        std::cout << "RUNNING TestCloneRectangle: ";
        // call test and capture any messages in results
        if (TestCloneRectangle(&results)) {
          std::cout << "COMPLETED (check valgrind for correctness)" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
      case 2:  // test Clone with jagged array
        std::cout << "RUNNING TestCloneJagged: ";
        // call test and capture any messages in results
        if (TestCloneJagged(&results)) {
          std::cout << "COMPLETED (check valgrind for correctness)" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
    }
  }
  return false;
}


bool TestCloneRectangle(std::string* results) {
  // clone test array
  char **actual = Clone(kRectangleInitialized, kRectangleRows, kRectangleCols);

  // compare to expected
  bool passed = ArraysEqual(kRectangleInitialized,
                            const_cast<const char**>(actual),
                            kRectangleRows, kRectangleCols);

  if (!passed)
  // when test failed, print cause
    *results = FormatFailString(kRectangleInitialized,
                                const_cast<const char**>(actual),
                                kRectangleRows,
                                kRectangleCols)
             + '\n';

  // return Cloned memory
  Deallocate(kRectangleRows, kRectangleCols, actual);

  return passed;
}


bool TestCloneJagged(std::string* results) {
  // clone test array
  char **actual = Clone(kJagged, kJaggedRows, kJaggedCols);

  // compare to expected
  bool passed = ArraysEqual(kJagged,
                            const_cast<const char**>(actual),
                            kJaggedRows, kJaggedCols);

  if (!passed)
  // when test failed, print cause
    *results = FormatFailString(kJagged,
                                const_cast<const char**>(actual),
                                kJaggedRows,
                                kJaggedCols)
             + '\n';

  // return Cloned memory
  Deallocate(kJaggedRows, kJaggedCols, actual);


  return passed;
}
