// Copyright 2023 CSCE 240
//
#include <hw3/inc/test_utils.h>



bool ArraysEqual(const char** lhs, const char** rhs,
                 std::size_t rows, const std::size_t cols[]) {
  for (std::size_t i = 0; i < rows; ++i)
    for (std::size_t ii = 0; ii < cols[i]; ++ii)
      if (lhs[i][ii] != rhs[i][ii])
        return false;

  return true;
}


const std::string FormatFailString(const char** expected,
                                   const char** actual,
                                   std::size_t rows,
                                   const std::size_t cols[]) {
  std::stringstream formatter;

  // add rows of expected matrix to stream
  formatter << "  Expected: {" << std::endl;
  for (const char **itr = expected, **end = expected + rows;
       itr != end;
       ++itr) {
    formatter << "    ";
    *FormatFailString(*itr, cols[itr - expected], &formatter)
      << (itr + 1 != expected + rows ? "," : "") << std::endl;
  }
  // add rows of actual matrix to stream
  formatter << "  }, Actual: {" << std::endl;
  for (const char **itr = actual, **end = actual + rows; itr != end; ++itr) {
    formatter << "    ";
    *FormatFailString(*itr, cols[itr - actual], &formatter)
      << (itr + 1 != end ? "," : "") << std::endl;
  }
  formatter << "  }";

  return formatter.str();
}


std::stringstream* FormatFailString(const char* from,
                                    std::size_t cols,
                                    std::stringstream* to) {
  *to << "{ ";

  // print each column/char in row, delimit with commas
  for (const char *itr = from, *end = from + cols; itr != end; ++itr)
    *to << '\'' << *itr << '\'' << (itr + 1 != end ? ", " : "");
  
  *to << " }";

  return to;
}
