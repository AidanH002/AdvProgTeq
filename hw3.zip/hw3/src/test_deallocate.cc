// Copyright 2023 CSCE 240
//
#include <hw3/inc/test_char_matrix.h>


// tests Deallocate function's correctness deleteing a rectangular array
bool TestDeallocateRectangle(std::string* results);

// tests Deallocate function's correctness deleting a jagged array
bool TestDeallocateJagged(std::string* results);

// recursive; used to call one or both of the two above-declared functions
bool TestDispatcher(int test = 0);


// main function
//
// Entry point to tests
int main(int argc, char* argv[]) {
  const std::size_t kTestNoArg = 1;

  // if no test no NOT provided, any integer NOT in [1, 2] will work; using -1
  if (TestDispatcher(argc == 1 ? -1 : std::atoi(argv[kTestNoArg])))
    // test(s) successful
    return 0;

  return 1;
}


// 
bool TestDispatcher(int test) {
  if (test != 1 && test != 2) {
    // input is not valid test; run all tests
    bool passed = true;
    for (int i = 1; i < 3; ++i)
      passed = TestDispatcher(i) && passed;
    
    return passed;
  } else {
    std::string results;  // messages from test functions

    switch (test) {
      case 1:
        // test Deallocate with rectangular array
        std::cout << "RUNNING TestDeallocateRectangle: ";
        // call test and capture any messages in results
        if (TestDeallocateRectangle(&results)) {
          std::cout << "COMPLETED (check valgrind for correctness)" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
      case 2:  // test Deallocate with jagged array
        std::cout << "RUNNING TestDeallocateJagged: ";
        // call test and capture any messages in results
        if (TestDeallocateJagged(&results)) {
          std::cout << "COMPLETED (check valgrind for correctness)" << std::endl;

          return true;
        } else {
          std::cout << "FAILED\n" << results << std::endl;

          return false;
        }
    }
  }
  return false;
}


bool TestDeallocateRectangle(std::string* results) {
  // request memory
  char **actual = Allocate(kRectangleRows, kRectangleCols);

  // compare to expected
  bool passed = ArraysEqual(kRectangleDefault,
                            const_cast<const char**>(actual),
                            kRectangleRows, kRectangleCols);

  if (!passed)
  // when test failed, print cause
    *results = FormatFailString(kRectangleDefault,
                                const_cast<const char**>(actual),
                                kRectangleRows,
                                kRectangleCols)
             + '\n';

  // test Deallocate function
  Deallocate(kRectangleRows, kRectangleCols, actual);

  // must pass both tests to pass function
  return passed;
}


bool TestDeallocateJagged(std::string* results) {
  // request arrays
  char **actual = Allocate(kJaggedRows, kJaggedCols, kInitVal);

  // compare to expected
  bool passed = ArraysEqual(kJagged,
                            const_cast<const char**>(actual),
                            kJaggedRows, kJaggedCols);

  if (!passed)
  // when test failed, print cause
    *results = FormatFailString(kJagged,
                                const_cast<const char**>(actual),
                                kJaggedRows,
                                kJaggedCols)
             + '\n';

  // test Deallocate function
  Deallocate(kJaggedRows, kJaggedCols, actual);

  // must pass both tests to pass function
  return passed;
}
