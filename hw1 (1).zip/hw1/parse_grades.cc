// DO NOT CHANGE FILE EXTENSION, FILE NAME, DIRECTORY NAME, OR DIRECTORY
// STRUCTURE
//
// The contents of this file are yours to do with as you please. You may change
// any/every aspect of this file's contained data.


int main(int argc, char* argv[]) {

  return 0;
}

