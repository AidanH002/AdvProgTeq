// Copyright 2023 CSCE 240
//
#ifndef LECTURE5_INC_SUMMATION_H_
#define LECTURE5_INC_SUMMATION_H_


#include <lecture5/inc/rational.h>

#include <cstddef>
#include <iostream>
#include <ostream>

class Summation {
 public:
  Summation() : store_(nullptr), capacity_(0), size_(0) {
    std::cout << "Summation::Summation()" << std::endl;
  }

  // range constructor
  // fills from an array starting at first to one less than last
  Summation(const Rational* first, const Rational* last); 

  // copy constructor
  Summation(const Summation&);

  // destructor
  ~Summation();

  // assignment operator
  Summation& operator=(const Summation&);

  // adds another rational to the summation
  void Add(const Rational&);
  Summation& operator+=(const Rational& that);

  Rational& operator[](std::size_t) const;

  const Summation operator+(const Summation& rhs) const;

  const Rational Sum(std::size_t start, std::size_t end) const;

  std::ostream* Extract(std::ostream*) const;

 private:
  Rational* store_;
  std::size_t capacity_;
  std::size_t size_;
};

inline std::ostream& operator<<(std::ostream& lhs, const Summation& rhs) {
  return *rhs.Extract(&lhs);
}

#endif   // LECTURE5_INC_SUMMATION_H_
