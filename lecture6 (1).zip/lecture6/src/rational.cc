// Copyright 2023 CSCE 240
//
#include <lecture5/inc/rational.h>

Rational::Rational() : num_(0), den_(1), positive_(true) {
  // empty
}


Rational::Rational(int num, int den) {
  // (a + b)' == a'b', (a * b)' == a' + b'
  positive_ = (num < 0 || den >= 0) && (num >= 0 || den < 0);

  num_ = std::abs(num);
  den_ = std::abs(den);
}


const Rational Rational::Add(const Rational& rhs) const {
  return Rational(
    (positive_ ? 1 : -1) * num_ * rhs.den_
      + (rhs.positive_ ? 1 : -1) * rhs.num_ * den_,
    den_ * rhs.den_);
}


std::ostream* Rational::Extract(std::ostream* output) const {
  int gcd = GCD(num_, den_);
  int num = num_ / gcd, den = den_ / gcd;
  *output << (positive_ ? "" : "-") << num << "/" << den;
  return output;
}

std::istream* Rational::Insert(std::istream* input) {
  char slash;  // buffer to extract slash character
  *input >> num_ >> slash >> den_;
  positive_ = (num_ < 0 && den_ < 0) || (num_ > 0 && den_ > 0);
  num_ = std::abs(num_);
  den_ = std::abs(den_);
  return input;
}

int Rational::GCD(int a, int b) const {
  int swap;
  while (b) {
    swap = b;
    b = a % b;
    a = swap;
  }
  return a;
}


std::istream& operator>>(std::istream& lhs, Rational& rhs) {
  rhs.Insert(&lhs);  // call public Rational::Insert
  return lhs;
}


std::ostream& operator<<(std::ostream& lhs, const Rational& rhs) {
  rhs.Extract(&lhs);  // call public Rational::Extract
  return lhs;
}
