// Copyright 2023 CSCE240
//
#include <lecture6/inc/test_stack.h>


const std::string& EmptyStack(csce240::Stack* from, std::string* into) {
  if (from->Empty())
    return *into;

  *into += from->Pop();
  while (!from->Empty())
    *into += ", " + from->Pop();
  return *into;
}


const csce240::Stack& LoadStack(csce240::Stack* s) {
  const std::string *end = kVideos + sizeof(kVideos) / sizeof(std::string);

  for (const std::string *itr = kVideos; itr != end; ++itr)
    s->Push(*itr);

  return *s;
}


const std::vector<std::string>& LoadVector(std::vector<std::string>* vector) {
  const std::string *end = kVideos + kVideosSize;

  for (const std::string *itr = kVideos; itr != end; ++itr)
    vector->push_back(*itr);

  return *vector;
}


std::ostream& operator<<(std::ostream& lhs,
                         const std::vector<std::string>& rhs) {
  for (auto it = rhs.begin(); it != rhs.end(); ++it)
    lhs << *it << ' ';
  return lhs;
}

int main(int argc, char* argv[]) {
  csce240::Stack stack1, stack2;
  std::string stack_string;

  std::cout << "std::vector: " << LoadVector(&stack1) << std::endl;
  std::cout << "csce240::Stack: " << EmptyStack(&stack1, &stack_string)
    << std::endl;

  std::cout << "csce240::Stack: " << LoadStack(&stack2) << std::endl;
  stack_string = "";
  std::cout << "csce240::Stack: " << EmptyStack(&stack2, &stack_string)
    << std::endl;

  return 0;
}
