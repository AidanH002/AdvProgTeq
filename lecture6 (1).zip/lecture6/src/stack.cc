// Copyright 2023 CSCE240
//
#include <lecture6/inc/stack.h>

