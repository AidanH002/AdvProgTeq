// Copyright 2023 CSCE 240
//
#include <lecture6/inc/test_queue.h>


int main(int argc, char* argv[]) {
  csce240::Queue q1, q2;
  std::string q_string;

  std::cout << "std::list: " << LoadList(&q1) << std::endl;
  std::cout << "csce240::Queue: " << EmptyQueue(&q1, &q_string)
    << std::endl;

  std::cout << "csce240::Queue: " << LoadQueue(&q2) << std::endl;
  q_string = "";
  std::cout << "csce240::Queue: " << EmptyQueue(&q2, &q_string)
    << std::endl;

  return 0;
}


const std::list<std::string>& LoadList(std::list<std::string>* list) {
  const std::string *end = kVideos + sizeof(kVideos) / sizeof(std::string);

  for (const std::string *itr = kVideos; itr != end; ++itr)
    list->push_back(*itr);

  return *list;
}


const csce240::Queue& LoadQueue(csce240::Queue* q) {
  const std::string *end = kVideos + kVideosSize;

  for (const std::string *itr = kVideos; itr != end; ++itr)
    q->Push(*itr);

  return *q;
}


const std::string& EmptyQueue(csce240::Queue* from, std::string* into) {
  while (!from->Empty())
    *into += from->Pop() + ' ';
  return *into;
}

std::ostream& operator<<(std::ostream& lhs, const std::list<std::string>& rhs) {
  for (auto it = rhs.begin(); it != rhs.end(); ++it)
    lhs << *it << ' ';
  return lhs;
}

