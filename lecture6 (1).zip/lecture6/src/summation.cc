// Copyright 2023 CSCE 240
//
#include <lecture5/inc/summation.h>

Summation::Summation(const Rational* first, const Rational* last) : store_(nullptr),
                                                                    capacity_(0),
                                                                    size_(0) {
  size_ = last - first;  // last = 800, first = 0, size_ = 100 if sizeof(*first) == 8
  capacity_ = size_ + 1;
  store_ = new Rational[capacity_];

  for (Rational* itr = store_; first != last; ++itr, ++first)
    *itr = *first;
}


Summation::Summation(const Summation& that) {
  std::cout << "Summation::Summation(const Summation&)" << std::endl;
  capacity_ = that.capacity_;
  store_ = new Rational[capacity_];

  size_ = that.size_;
  for (std::size_t i = 0; i < size_; ++i)
    store_[i] = that.store_[i];
}


Summation::~Summation() {
  std::cout << "Summation::~Summation()" << std::endl;
  if (store_) {  // not necessary here, but would be sometimes, i.e. a 2d array
    delete [] store_;
  }
}


Summation& Summation::operator=(const Summation& that) {
  std::cout << "Summation& Summation::operator=(const Summation&)" << std::endl;
  if (this == &that)  // ensure object not assigned to itself
    return *this;

  if (store_) {  // rhs instance held data  
    delete [] store_;
  }

  capacity_ = that.capacity_;  // note rhs capacity
  store_ = new Rational[capacity_];  // allocate enough memory for rhs capacity

  size_ = that.size_;  // not rhs size
  for (std::size_t i = 0; i < size_; ++i)
    store_[i] = that.store_[i];  // copy rhs elements to lhs

  return *this;
}


void Summation::Add(const Rational& element) {
  if (!store_) {  // first time Add called after default constructor
    capacity_ = 2;
    store_ = new Rational[capacity_];
  }

  if (size_ >= capacity_) {  // array is full, double capacity
    // double capacity attribute
    capacity_ = capacity_ << 1;
    // create new array doubling size
    Rational *tmp = new Rational[capacity_];
    // copy all elements from existing array to new array
    for (std::size_t i = 0; i < size_; ++i)
      tmp[i] = store_[i];
    // delete old memory
    delete [] store_;
    // update pointer to new memory
    store_ = tmp;
  }

  store_[size_] = element;
  ++size_;
}

Summation& Summation::operator+=(const Rational& that) {
  Add(that);
  return *this;
}

Rational& Summation::operator[](const std::size_t index) const {
  return store_[index];
}

const Rational Summation::Sum(std::size_t start, std::size_t end) const {
  Rational sum(0, 1);

  for (std::size_t i = start; i < end; ++i) {
    std::cout << sum << " + " << store_[i];
    sum = sum + store_[i];
  }

  return sum;
}

const Summation Summation::operator+(const Summation& rhs) const {
  Summation sum;
  sum.size_ = size_ + rhs.size_;
  sum.capacity_ = sum.size_;
  sum.store_ = new Rational[sum.capacity_];
  
  std::size_t i = 0;
  for(; i < size_; ++i)
    sum.store_[i] = rhs.store_[i];
  for(std::size_t j = 0; j < rhs.size_ && i < sum.size_; ++i, ++j)
    sum[i] = rhs.store_[j];

  return sum;
}

std::ostream* Summation::Extract(std::ostream* output) const {
  if (store_) {
    *output << store_[0];
    for (std::size_t i = 1; i < size_; ++i)
      *output << " + " << store_[i];
  } else {
    // empty set
    *output << '0';
  }
  return output;
}
