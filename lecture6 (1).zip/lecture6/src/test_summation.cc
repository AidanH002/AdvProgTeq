// Copyright 2023 CSCE 240
//


#include <lecture5/inc/summation.h>
#include <lecture5/inc/rational.h>

#include <iostream>

int main(int argc, char* argv[]) {
  Summation test_sum_1;  // default constructor

  for (int i = 1; i <= 10; ++i)
    test_sum_1 += Rational(1, 1 << i);

  std::cout << test_sum_1 << std::endl;  // extraction operator

  Summation test_sum_2(test_sum_1);  // copy constructor

  test_sum_1 = test_sum_2;  // assignment operator

  const std::size_t kRationalsSize = 4;
  const Rational *rationals = new Rational[kRationalsSize] {
    Rational(1, 2), Rational(1, 3), Rational(7, 8), Rational(15, 16)
  };

  Summation test_sum_3(rationals, rationals + kRationalsSize);

  std::cout << test_sum_1.Sum(0, kRationalsSize) << std::endl;
  std::cout << test_sum_1(0, kRationalsSize) << std::endl;

  delete [] rationals;

  return 0;
}
