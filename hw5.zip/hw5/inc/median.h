
#include <hw5/inc/statistic.h>

// Create the concrete class csce240::Median to extend csce240::Statistic.
// Ensure it overrides and implements all abstract methods of its parent and
// implements its own methods as necessary, i.e. operator[].
//
// The operator[] should accept an std::size_t and not change the calling class
// instance; is const.

