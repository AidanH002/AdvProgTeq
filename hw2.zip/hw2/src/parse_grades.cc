
const std::string ToString(const ParseErrors& error) {
  switch (error) {
    case ParseErrors::kNoErrors:
      return "kNoErrors";
    case ParseErrors::kNoStudents:
      return "kNoStudents";
    case ParseErrors::kNoExams:
      return "kNoExams";
    case ParseErrors::kNoQuizzes:
      return "kNoQuizzes";
    case ParseErrors::kMissingStudent:
     return "kMissingStudent";
    case ParseErrors::kMissingExam:
      return "kMissingExam";
    case ParseErrors::kMissingQuiz:
      return "kMissingQuiz";
    default:
      // not possible with enum
      return std::string();
  }
}


