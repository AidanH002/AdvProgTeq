// This file is yours to modify as needed to pass styling, compile, and to pass
// all execution tests. You should not modify the public interface, except as
// necessary to pass the tests. Make sure you can and do read this entire file;
// future exams will assume you are doing so. DELETE THIS MESSAGE and replace
// it with your own documentation before submitting the file.
//
#include <cstddef>
#include <string>


// Describes any exceptional execution paths of the following functions, or the
// lack thereof (kNoErrors)
enum class ParseErrors {
  kNoErrors,
  kNoStudents,
  kNoExams,
  kNoQuizzes,
  kMissingStudent,
  kMissingExam,
  kMissingQuiz
};

// Translates the above enum values into strings for printing
const std::string ToString(const ParseErrors& error);


// Returns the number of students found in the string array parameter values[]
// as specified by the input format in hw2.pdf.
//
//   + Precondition: size parameter is no larger than the number of elements in
//                   values[] parameter
//   + Postcondition: when output parameter errors is not nullptr, it will
//                    contain:
//       * kNoErrors : when execution is normal
//       * kNoStudents : when number of students is 0
//   + Returns: unsigned integral value of number of students
std::size_t ParseNumStudents(const std::string values[],
                             std::size_t size,
                             ParseErrors* errors = nullptr);


// Returns the number of exams for a student specified by string id parameter
// found in the string array parameter.
//
//   + Precondition: size parameter is no larger than the number of elements in
//                   values[] parameter
//   + Postcondition: when output parameter errors is not nullptr, it will
//                    contain:
//       * kNoErrors
//       * kNoStudents when number of students is 0
//       * kNoExams when number of exams is 0
//       * kMissing student if student id is not found
//   + Returns: an unsigned integer value representing the number of exams for
//              a student specified by the stu_id paramter
std::size_t ParseNumExams(const std::string& stu_id,
                          const std::string values[],
                          std::size_t size,
                          ParseErrors* errors = nullptr);


// Returns the quiz values for a student, given the student's stu_id.
//
//   + Preconditions:
//       * size parameter is no larger than the number of elements in values
//       * quiz_values output parameter is large enough to hold all quiz values
//         for the specified student id
//   + Postconditions:
//       * Output parameter quiz_values contains the quiz values for the
//         student specified by the stu_id parameter
//       * When if output parameter errors is not nullptr, it will contain
//         - kNoErrors : when execution normal
//         - kNoStudents : when number of students is 0
//         - kMissingStudent : student if student id is not found
//         - kNoQuizzes : when no quizzes are found
//   + Returns:
//       * An unsigned integral value representing the number of quiz values
//         copied into the output parameter quiz_values,
//       * A 0 if there are no students, quizzes, or the specified student id
//         does not exist.
std::size_t ParseQuizValues(const std::string& stu_id,
                            const std::string values[],
                            std::size_t size,
                            double quiz_values[],
                            ParseErrors* errors = nullptr);
